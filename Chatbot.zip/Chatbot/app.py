from flask import Flask, render_template, request, jsonify
import os
import google.generativeai as genai
import re
from dotenv import load_dotenv

app = Flask(__name__)

# Load API key from .env file
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Gemini model
model = genai.GenerativeModel("gemini-1.5-pro-latest")

# Valid keywords related to India routes, cities, and states
VALID_KEYWORDS = [
    # Cities
    "delhi", "mumbai", "kolkata", "chennai", "bangalore", "hyderabad", "ahmedabad", "pune", "jaipur", "lucknow",
    "agra", "kochi", "goa", "varanasi", "srinagar", "darjeeling", "shimla", "manali", "udaipur", "mysore", "amritsar", "rishikesh", "haridwar", "ooty", "pondicherry", "gangtok", "leh", "jaisalmer", "bhopal",
    "gwalior", "indore", "rajkot", "surat", "nagpur", "dehradun", "guwahati", "trivandrum", "coimbatore",
    "madurai", "visakhapatnam", "tirupati", "ajmer", "nainital", "kanpur", "chandigarh", "patna",

    # States and Union Territories
    "andhra pradesh", "arunachal pradesh", "assam", "bihar", "chhattisgarh", "goa", "gujarat", "haryana",
    "himachal pradesh", "jharkhand", "karnataka", "kerala", "madhya pradesh", "maharashtra", "manipur",
    "meghalaya", "mizoram", "nagaland", "odisha", "punjab", "rajasthan", "sikkim", "tamil nadu", "telangana",
    "tripura", "uttar pradesh", "uttarakhand", "west bengal", "andaman and nicobar islands",
    "chandigarh", "dadra and nagar haveli and daman and diu", "lakshadweep", "delhi", "puducherry",
    "jammu and kashmir", "ladakh",

    # Route and Travel related terms
    "route", "travel", "journey", "direction", "way", "path", "distance", "time", "reach", "go to",
    "from", "to", "via", "between", "how to get to", "best way to travel", "road", "train", "flight",
    "bus", "car", "map", "itinerary", "plan", "suggest", "recommend", "explore", "visit", "Best","places"
    "travel guide", "distance between", "travel time", "driving directions", "train routes",
    "flight routes", "bus routes", "attractions in", "places to visit in","Famous","Tourists","how to reach", "travel time", "best route", "directions to", 
    "nearby places", "closest", "cheapest way","fastest route","how far is","places near", "tour plan", "top spots",
    "famous places", "travel guide","journey plan", "must-see", "itinerary ideas", "local transport", "trip suggestions",
    "trip duration","connectivity", "direct route", "stopover", "tourist routes", "sightseeing", "local attractions",
    "weekend getaway", "day trip", "top destinations", "route map", "shortest way", "scenic route", "train", "flight", "bus", "car", "taxi", "cab", "auto", "metro", "rickshaw", "ferry", "bike", "scooter",
    "public transport", "rental car", "cab service", "shared taxi", "tour bus", "direct train",
    "night bus", "airport taxi", "railway station", "bus stand", "ticket booking", "transport options"

    #Time and Seasons
    "best time to visit", "season", "summer", "winter", "monsoon", "rainy season", "weather", "temperature",
    "climate", "off season", "peak season", "weekend", "holiday", "long weekend", "festival time",
    "when to go", "ideal time", "timing", "open hours", "visiting hours", "closing time", "sunrise", "sunset"

    # Cardinal directions (useful for describing routes)
    "north", "south", "east", "west", "northeast", "northwest", "southeast", "southwest","left", "right", "straight", "ahead", "near", "far", "opposite", "close to", "around"

    #Travel Experience
    "heritage", "spiritual", "beach", "mountain", "hill station", "wildlife", "trekking", "shopping",
    "street food", "nightlife", "cafes", "restaurants", "adventure", "religious places", "historical",
    "cultural events", "fairs", "festivals", "art", "music", "local experience", "offbeat places",
    "romantic places", "family friendly", "solo travel", "group travel"

    #General Search Intents
    "what is there", "show me", "suggest me", "help me", "I want to", "where can I", "nearby",
    "what to see", "where is", "how to go", "give me info", "search", "guide me", "help plan",
    "list of", "information about", "travel ideas", "recommend me", "must see", "language support", "language spoken", "local language", "how to say", "translate", 
    "common phrases", "basic language", "greetings in", "useful words", "speak in", 
    "understand language", "language barrier"

    #Food & Local Cuisine
    "famous food", "local cuisine", "must try food", "restaurants", "cafes", "street food", "dhaba",
    "veg", "non veg", "thali", "snacks", "sweets", "drinks", "where to eat", "best food", "popular dishes",
    "specialty", "food joints", "breakfast", "lunch", "dinner", "night food", "food festival", "food"

    #Activities & Experiences
    "things to do", "sightseeing", "activities", "adventure sports", "boating", "trekking", "camping",
    "heritage walk", "nature walk", "jungle safari", "photography spots", "shopping places",
    "souvenirs", "spa", "wellness", "yoga", "meditation centers", "amusement park", "water park",
    "events", "concerts", "cultural show", "local market", "shopping mall"

    #Landmark and Place Types
    "temple", "church", "mosque", "fort", "palace", "museum", "zoo", "park", "lake", "beach", "hill",
    "mountain", "river", "waterfall", "valley", "viewpoint", "garden", "historical monument",
    "heritage site", "market", "shopping street", "bazaar", "island", "forest", "sanctuary", "Tirupati", "Araku Valley", "Vizag (Visakhapatnam)", "Vijayawada", 
    "Lepakshi", "Tawang", "Ziro Valley", "Bomdila", "Itanagar", "Dirang", "Kaziranga National Park", "Majuli Island", "Guwahati", 
    "Sivasagar", "Haflong", "Bodh Gaya", "Nalanda", "Rajgir", "Patna", "Vaishali", "Chitrakote Waterfalls", "Jagdalpur", 
    "Barnawapara Wildlife Sanctuary", "Raipur", "Sirpur", "Baga Beach", "Calangute", "Old Goa Churches", "Dudhsagar Falls", 
    "Palolem", "Rann of Kutch", "Gir National Park", "Dwarka", "Somnath", "Ahmedabad", "Kurukshetra", "Morni Hills", 
    "Pinjore Gardens", "Sultanpur Bird Sanctuary", "Panchkula", "Shimla", "Manali", "Dharamshala", "Spiti Valley", 
    "Kullu", "Netarhat", "Betla National Park", "Deoghar", "Ranchi", "Hazaribagh", "Hampi", "Coorg", "Mysore", "Gokarna", 
    "Chikmagalur", "Munnar", "Alleppey (Alappuzha)", "Wayanad", "Kochi", "Thekkady", "Khajuraho", "Bandhavgarh National Park", 
    "Kanha National Park", "Bhopal", "Pachmarhi", "Mumbai", "Lonavala & Khandala", "Mahabaleshwar", "Ajanta & Ellora Caves", 
    "Shirdi", "Loktak Lake", "Imphal", "Keibul Lamjao National Park", "Moreh", "Andro Village", "Shillong", "Cherrapunji", "Dawki", 
    "Mawlynnong", "Laitlum Canyons", "Aizawl", "Champhai", "Reiek", "Vantawng Falls", "Hmuifang", "Kohima", "Dzukou Valley", "Mokokchung", "Mon", "Khonoma", "Puri", "Konark Sun Temple", "Bhubaneswar", "Chilika Lake",
    "Simlipal National Park", "Amritsar (Golden Temple)", "Chandigarh", "Anandpur Sahib", "Patiala", "Wagah Border", "Jaipur", "Udaipur", "Jaisalmer", "Jodhpur", "Mount Abu", "Gangtok", "Nathula Pass", "Yumthang Valley", 
    "Pelling", "Lachung", "Ooty", "Kodaikanal", "Madurai", "Rameswaram", "Mahabalipuram", "Hyderabad", "Warangal", "Nagarjuna Sagar", "Bhadrachalam", "Medak Fort", "Agartala", "Ujjayanta Palace", "Neermahal", "Unakoti", "Jampui Hills", "Agra (Taj Mahal)", 
    "Varanasi", "Lucknow", "Mathura-Vrindavan", "Sarnath", "Rishikesh", "Haridwar", "Nainital", "Mussoorie", "Auli", "Kolkata", "Darjeeling", "Sundarbans", "Kalimpong", "Digha", "Havelock Island", "Neil Island", "Cellular Jail", "Radhanagar Beach", "Rock Garden", "Sukhna Lake", "Rose Garden", "Diu Fort", "Devka Beach", 
    "Vanganga Garden", "India Gate", "Red Fort", "Qutub Minar", "Lotus Temple", "Chandni Chowk", "Srinagar", "Gulmarg", "Pahalgam", "Sonamarg", "Vaishno Devi", "Leh", "Pangong Lake", "Nubra Valley", "Magnetic Hill", "Tso Moriri", "Agatti Island", "Kavaratti", 
    "Bangaram", "Minicoy", "Auroville", "Paradise Beach", "French Colony", "Promenade Beach"


    #Purpose-Based Travel Keywords
    "honeymoon", "solo trip", "family vacation", "pilgrimage", "business trip", "backpacking",
    "study tour", "cultural trip", "spiritual journey", "weekend getaway", "short trip", "long trip",
    "road trip", "beach vacation", "hill station tour", "friends trip"

    #State wise languages
    "assamese", "bengali", "bodo", "dogri", "gujarati", "hindi", "kannada", "kashmiri", 
    "konkani", "maithili", "malayalam", "manipuri", "marathi", "nepali", "oriya", 
    "punjabi", "sanskrit", "santali", "sindhi", "tamil", "telugu", "urdu", "english", 
    "rajasthani", "garhwali", "pahari", "bhili", "mizo", "kokborok", "khasi", "garo", 
    "nagamese", "tulu", "tribal languages", "local dialect", "regional language"

    #Local Culture
    "local culture", "traditions", "customs", "local dress", "folk dance", "folk music", 
    "cultural events", "local art", "local music", "cultural heritage", "crafts", 
    "handicrafts", "lifestyle", "community culture", "local rituals"

    #Emergency Info
    "emergency", "emergency number", "help", "hospital", "nearby hospital", "medical help", 
    "pharmacy", "ambulance", "clinic", "emergency room", "police", "police station", 
    "nearest police station", "safety", "crime", "report issue", "lost item", "contact police", 
    "fire station", "blood bank", "COVID help", "tourist helpline"

    #Accomdations
    "hotels", "resorts", "homestay", "lodge", "hostel", "Airbnb", "guest house", "budget stay",
    "luxury stay", "room booking", "places to stay", "accommodation options", "night stay",
    "nearby hotel", "affordable", "comfortable stay", "view room", "sea-facing", "hill view"

    #AndhraPradesh
    "Anantapur", "Lepakshi", "Penukonda Fort", "Alampur", "Puttaparthi",
    "Chittoor", "Tirupati", "Kanipakam", "Sri Kalahasti", "Venkateswara Temple",
    "East Godavari", "Rajahmundry", "Papikondalu", "Kakinada", "Peddaganjam",
    "Guntur", "Amaravati", "Undavalli Caves", "Prakasam Barrage", "Guntur Fort",
    "Krishna", "Vijayawada", "Kanaka Durga Temple", "Bhavani Island", "Prakasam Barrage",
    "Kurnool", "Belum Caves", "Konda Reddy Fort", "Yaganti", "Mahanandi",
    "Nellore", "Pulicat Lake", "Narasimha Swamy Temple", "Srikalahasti", "Udayagiri Fort",
    "Prakasam", "Chandavaram Buddhist Site", "Kothapatnam Beach", "Chilakaluripet",
    "Srikakulam", "Arasavalli Sun Temple", "Baruva Beach", "Srikurmam", "Suryanarayana Temple",
    "Visakhapatnam", "Araku Valley", "Borra Caves", "Rishikonda Beach", "Kailasagiri",
    "Vizianagaram", "Ramatheertham", "Thotapalli Barrage", "Sankaram", "Vizianagaram Fort",
    "West Godavari", "Perupalem Beach", "Dwaraka Tirumala", "Rajahmundry", "Kolleru Lake",
    "YSR Kadapa", "Gandikota", "Pushpagiri", "Madhavaram", "Bhakra Reservoir"

    #ArunachalPradesh
    "Tawang", "Tawang Monastery", "Sela Pass", "Madhuri Lake",
    "West Kameng", "Bomdila", "Dirang Valley", "Sessa Orchid Sanctuary",
    "East Kameng", "Seppa", "Pakke Wildlife Sanctuary", "Pappu Valley",
    "Papum Pare", "Itanagar", "Ganga Lake", "Hollongi",
    "Lower Subansiri", "Ziro", "Talley Valley", "Danielli Wildlife Sanctuary",
    "Upper Subansiri", "Daporijo", "Menga Caves", "Yazali",
    "West Siang", "Along", "Mechuka Valley", "Raghunath Temple",
    "East Siang", "Pasighat", "Daying Ering Wildlife Sanctuary", "Komsing Village",
    "Upper Siang", "Yingkiong", "Mouling National Park", "Pangin",
    "Dibang Valley", "Anini", "Mehao Lake", "Dibang River",
    "Lower Dibang Valley", "Roing", "Mayudia Pass", "Nokrek National Park",
    "Lohit", "Tezu", "Parashuram Kund", "Wakro",
    "Changlang", "Namdapha National Park", "Miao", "Wangcha",
    "Tirap", "Khonsa", "Lazu Village", "Longding",
    "Longding", "Kanubari", "Pumao Village", "Khonoma"

    #Assam
    "Kamrup Metropolitan", "Guwahati", "Kamakhya Temple", "Umananda Island", "Assam State Zoo",
    "Dibrugarh", "Dibrugarh Town", "Dehing Patkai Wildlife Sanctuary", "Tea Gardens", "Joi Barua",
    "Jorhat", "Majuli Island", "Tocklai Tea Research Institute", "Jorhat Gymkhana", "Sivasagar",
    "Sivasagar", "Rang Ghar", "Talatal Ghar", "Sivasagar Tank", "Jorhat",
    "Tinsukia", "Dibru-Saikhowa National Park", "Digboi", "Tinsukia", "Chabua",
    "Hailakandi", "Hailakandi", "Silchar", "Kailashahar",
    "Karimganj", "Karimganj", "Assam-Bangladesh Border", "Kailashahar"

    #Bihar
    "Patna", "Patna Sahib", "Golghar", "Buddha Smriti Park", "Mahatma Gandhi Setu",
    "Gaya", "Bodh Gaya", "Mahabodhi Temple", "Barabar Caves",
    "Bhagalpur", "Mandar Hill", "Sultanganj", "Vikramshila University",
    "Muzaffarpur", "Litchi Garden", "Baba Garibnath Temple",
    "Nalanda", "Nalanda University Ruins", "Rajgir", "Vishwa Shanti Stupa",
    "Darbhanga", "Darbhanga Fort", "Kechari Temple",
    "Munger", "Munger Fort", "Kundeshwari Temple",
    "Saharsa", "Saharsa", "Bhagalpur", "Purnea",
    "Vaishali", "Vaishali Stupa", "Buddha Stupa"

    #Chhatisgarh
    "Raipur", "Mahamaya Temple", "Nandan Van Zoo", "Kailash Caves",
    "Bilaspur", "Kailash and Kotumsar Caves", "Malhar",
    "Durg", "Dongargarh", "Rajiv Lochan Temple",
    "Korba", "Hasdeo River", "Koriya", "Achanakmar Wildlife Sanctuary",
    "Rajnandgaon", "Kailash Ghat", "Raja Talab",
    "Raigarh", "Raigarh Fort", "Gandhi Ghat",
    "Jagdalpur", "Chitrakote Falls", "Tirathgarh Waterfalls"

    #Goa
    "North Goa", "Baga Beach", "Calangute Beach", "Fort Aguada", "Chapora Fort",
    "South Goa", "Palolem Beach", "Colva Beach", "Ancestral Goa", "Cabo De Rama Fort"

    #Gujarat
    "Ahmedabad", "Sabarmati Ashram", "Kankaria Lake", "Adalaj Stepwell", "Jama Masjid",
    "Surat", "Dumas Beach", "Sarthana Nature Park", "Surat Castle",
    "Vadodara", "Lakshmi Vilas Palace", "Sayaji Garden", "Baroda Museum and Picture Gallery",
    "Rajkot", "Wankaner Palace", "Ranjit Vilas Palace", "Kaba Gandhi No Delo",
    "Bhavnagar", "Takhteshwar Temple", "Blackbuck National Park",
    "Junagadh", "Girnar Hill", "Uperkot Fort", "Sasan Gir National Park",
    "Kutch", "Rann of Kutch", "Kalo Dungar", "Mandvi Beach",
    "Surendranagar", "Wadhwan", "Ranchhodraiji Temple",
    "Banaskantha", "Palanpur", "Ambaji Temple", "Kumbharia Jain Temple"

    #Haryana
    "Gurugram", "Kingdom of Dreams", "Cyber Hub", "Sheetala Mata Mandir",
    "Faridabad", "Surajkund", "ISKCON Faridabad",
    "Karnal", "Karnal Lake", "Shree Durga Mandir",
    "Panipat", "Panipat Battle Fields", "Kabuli Bagh Mosque", "Baba Gurgobind Singh",
    "Ambala", "Ambala Cantonment", "Rani Ka Talab", "Badshahi Bagh",
    "Hisar", "Firoz Shah Palace Complex", "Jindal Park", "Baba Farid's Tomb"

    #HimachalPradesh
    "Shimla", "The Ridge", "Jakhoo Temple", "Christ Church", "Kufri",
    "Manali", "Solang Valley", "Rohtang Pass", "Hidimba Devi Temple",
    "Kullu", "Great Himalayan National Park", "Raghunath Temple",
    "Mandi", "Pandoh Dam", "Sundernagar", "Shikhari Devi Temple",
    "Kangra", "Kangra Fort", "Jwala Ji Temple", "Mata Chintpurni Temple"

    #Jharkhand
    "Ranchi", "Ranchi Lake", "Hundru Falls", "Tagore Hill", "Rock Garden",
    "Jamshedpur", "Tata Steel Zoological Park", "Surajkund",
    "Dhanbad", "Bhatinda Falls", "Maithon Dam", "Jharia",
    "Hazaribagh", "Hazaribagh National Park", "Bhadrakali Temple",
    "Giridih", "Trikut Pahar", "Parasnath Hills", "Madhuban Temple"

    #Karnataka
    "Bengaluru", "Cubbon Park", "Bangalore Palace", "Lalbagh Botanical Garden",
    "Mysuru", "Mysore Palace", "Chamundi Hill", "Brindavan Gardens",
    "Udupi", "Sri Krishna Temple", "Malpe Beach", "St. Mary's Island",
    "Mangalore", "Panambur Beach", "Kudroli Gokarnath Temple", "Tannirbhavi Beach",
    "Coorg", "Abbey Falls", "Raja's Seat", "Dubare Elephant Camp",
    "Hubli", "Chandramouleshwara Temple", "Unkal Lake"

    #Kerala
    "Thiruvananthapuram", "Padmanabhaswamy Temple", "Kovalam Beach", "Sree Chitra Art Gallery",
    "Kochi", "Fort Kochi", "Mattancherry Palace", "Santa Cruz Cathedral Basilica",
    "Munnar", "Tea Gardens", "Eravikulam National Park", "Mattupetty Dam",
    "Alappuzha", "Alleppey Backwaters", "Vembanad Lake", "Alappuzha Beach",
    "Kottayam", "Vembanad Lake", "Ettumanoor Mahadeva Temple", "Vagamon"

    #MadhyaPradesh
    "Bhopal", "Upper Lake", "Sanchi Stupa", "Bhimbetka Caves",
    "Indore", "Rajwada Palace", "Lal Baag Palace", "Kanch Mandir",
    "Ujjain", "Mahakaleshwar Temple", "Kal Bhairav Temple", "Bade Ganeshji Ka Mandir",
    "Gwalior", "Gwalior Fort", "Sas-Bahu Temples", "Gurjari Mahal"

    #Maharashtra
    "Mumbai", "Gateway of India", "Elephanta Caves", "Marine Drive", "Chhatrapati Shivaji Terminus",
    "Pune", "Shaniwar Wada", "Aga Khan Palace", "Sinhagad Fort", "Osho Ashram",
    "Nagpur", "Deekshabhoomi", "Futala Lake", "Seminary Hills",
    "Aurangabad", "Ajanta Caves", "Ellora Caves", "Bibi Ka Maqbara", "Daulatabad Fort",
    "Nashik", "Trimbakeshwar Temple", "Saptashrungi", "Pandav Leni Caves",
    "Kolhapur", "Mahalakshmi Temple", "Rankala Lake", "Panhala Fort",
    "Satara", "Kaas Plateau", "Satara Fort", "Sajjangad Fort",
    "Solapur", "Solapur Fort", "Bhimgiri Fort", "Ashtavinayak Temples",
    "Thane", "Yeoor Hills", "Masunda Lake", "Upvan Lake",
    "Shirdi", "Sai Baba Temple", "Dwarkamai", "Shani Shingnapur",
    "Ratnagiri", "Ganapatipule", "Jaigad Fort", "Ratnadurg Fort",
    "Sindhudurg", "Malvan", "Sindhudurg Fort", "Vengurla Beach"

    #Manipur
    "Imphal", "Shree Shree Govindajee Temple", "Loktak Lake", "Imphal War Cemetery",
    "Thoubal", "Keibul Lamjao National Park", "Bishnupur", "Langol Peak",
    "Churachandpur", "Churachandpur", "Tuibuong", "Nungshang",
    "Ukhrul", "Kachouphung Lake", "Shirui Hills", "Khayang Peak"

    #Meghalaya
    "Shillong", "Elephant Falls", "Umiam Lake", "Shillong Peak", "Ward’s Lake",
    "West Garo Hills", "Tura", "Balpakram National Park", "Siju Caves",
    "East Khasi Hills", "Cherrapunji", "Nohkalikai Falls", "Living Root Bridges",
    "South Garo Hills", "Nokrek National Park", "Baghmara", "Siju Wildlife Sanctuary"

    #Mizoram
    "Aizawl", "Durtlang Hills", "Mizoram State Museum", "Lalhmingthanga Park",
    "Champhai", "Phawngpui Blue Mountain", "Lengteng Wildlife Sanctuary",
    "Serchhip", "Tuirihiau Falls", "Vangchhia", "Mamit"

    #Nagaland
    "Kohima", "Kohima War Cemetery", "Shilloi Lake", "Zoological Park",
    "Dimapur", "Kachari Ruins", "Nagaland Science Centre", "Diphupar",
    "Mokokchung", "Mopungchuket", "Longkhum", "Chuchuyimlang",
    "Mon", "Konyak Village", "Shangnyu Village", "Noklak"

    #Odisha
    "Bhubaneswar", "Lingaraj Temple", "Udayagiri and Khandagiri Caves", "Nandankanan Zoo",
    "Cuttack", "Barabati Fort", "Cuttack Chandi Temple", "Netaji Birth Place",
    "Puri", "Jagannath Temple", "Konark Sun Temple", "Puri Beach",
    "Sambalpur", "Hirakud Dam", "Sambalpur", "Debrigarh Wildlife Sanctuary"

    #Punjab
    "Amritsar", "Golden Temple", "Jallianwala Bagh", "Durgiana Temple", "Wagah Border",
    "Ludhiana", "Punjab Agricultural University", "Rural Museum", "Ludhiana Clock Tower",
    "Patiala", "Qila Mubarak", "Sheesh Mahal", "Moti Bagh Palace",
    "Jalandhar", "Devi Talab Mandir", "Nikku Park", "Wonderland Theme Park"

    #Rajasthan
    "Jaipur", "Hawa Mahal", "Amber Fort", "City Palace", "Jantar Mantar",
    "Udaipur", "City Palace", "Lake Pichola", "Jagdish Temple", "Saheliyon Ki Bari",
    "Jodhpur", "Mehrangarh Fort", "Umaid Bhawan Palace", "Mandore Gardens",
    "Jaisalmer", "Jaisalmer Fort", "Sam Sand Dunes", "Patwon Ki Haveli",
    "Bikaner", "Junagarh Fort", "Lalgarh Palace", "Karni Mata Temple",
    "Pushkar", "Pushkar Lake", "Brahma Temple", "Camel Fair"

    #Sikkim
    "Gangtok", "Rumtek Monastery", "Tsomgo Lake", "Nathula Pass",
    "Namchi", "Samdruptse Hill", "Tarey Bhir", "Ngadak Monastery",
    "North Sikkim", "Yumthang Valley", "Gurudongmar Lake", "Lachung"

    #TamilNadu
    "Chennai", "Marina Beach", "Kapaleeshwarar Temple", "Fort St. George", "San Thome Cathedral",
    "Madurai", "Meenakshi Amman Temple", "Thirumalai Nayakkar Mahal", "Alagar Koyil",
    "Coimbatore", "Adiyogi Shiva Statue", "Kovai Kutralam", "Perur Patteeswarar Temple",
    "Ooty", "Ooty Lake", "Botanical Gardens", "Doddabetta Peak",
    "Tiruchirappalli", "Ranganathaswamy Temple", "Rockfort Temple", "Kallanai Dam"

    #Telangana
    "Hyderabad", "Charminar", "Golconda Fort", "Hussain Sagar", "Salar Jung Museum",
    "Warangal", "Warangal Fort", "Thousand Pillar Temple", "Badrakali Temple",
    "Khammam", "Khammam Fort", "Kinnerasani Wildlife Sanctuary",
    "Nizamabad", "Nizamabad Fort", "Alisagar Reservoir"

    #Tripura
    "Agartala", "Ujjayanta Palace", "Neermahal Palace", "Sepahijala Wildlife Sanctuary",
    "Unakoti", "Unakoti Hills", "Kailashahar", "Shiva Temple",
    "Dhalai", "Jampui Hills", "Naiyarang",
    "North Tripura", "Jampui Hills", "Unakoti", "Kailashahar"

    #UttarPradesh
    "Agra", "Taj Mahal", "Agra Fort", "Fatehpur Sikri",
    "Varanasi", "Kashi Vishwanath Temple", "Dashashwamedh Ghat", "Sarnath",
    "Lucknow", "Bara Imambara", "Chota Imambara", "Rumi Darwaza",
    "Mathura", "Krishna Janmabhoomi", "Dwarkadhish Temple", "Vrindavan",
    "Aligarh", "Aligarh Fort", "Sir Syed Academy Museum", "Mughal Gardens"

    #Uttarakhand
    "Dehradun", "Robber’s Cave", "Sahastradhara", "Tapkeshwar Temple",
    "Haridwar", "Har Ki Pauri", "Maya Devi Temple", "Chandi Devi Temple",
    "Nainital", "Naini Lake", "Naina Devi Temple", "Snow View Point",
    "Rishikesh", "Lakshman Jhula", "Triveni Ghat", "Neelkanth Mahadev Temple"

    #WestBengal
    "Kolkata", "Victoria Memorial", "Howrah Bridge", "Indian Museum", "Marble Palace",
    "Darjeeling", "Tiger Hill", "Batasia Loop", "Darjeeling Himalayan Railway",
    "Siliguri", "Mahananda Wildlife Sanctuary", "Siliguri Junction",
    "Murshidabad", "Hazarduari Palace", "Imambara", "Katra Mosque",
    "Digha", "Digha Beach", "Talsari Beach"

]

def is_prompt_valid(prompt):
    prompt = prompt.lower()
    for keyword in VALID_KEYWORDS:
        if re.search(rf'\b{re.escape(keyword)}\b', prompt):
            return True
    return False

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    prompt = data.get("message", "")

    if not is_prompt_valid(prompt):
        return jsonify({"reply": "This prompt is out of scope. Please ask questions related to routes, cities, or states within India."})

    try:
        # Modify the prompt to strongly guide the LLM towards route information
        route_prompt = f"Provide information about routes, cities, and states within India based on the following query: {prompt}. If the query is not clearly about India routes, cities, or states, respond with 'This query is outside the scope of India route guidance.'"
        response = model.generate_content(route_prompt)

        # Check if the LLM explicitly stated it's out of scope
        if "outside the scope of India route guidance" in response.text.lower():
            return jsonify({"reply": "This prompt is out of scope. Please ask questions related to routes, cities, or states within India."})
        else:
            return jsonify({"reply": response.text})

    except Exception as e:
        print("Error:", e)
        return jsonify({"reply": "API Error."})

if __name__ == "__main__":
    app.run(debug=True)